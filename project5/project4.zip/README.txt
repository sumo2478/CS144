CS144 Project 4 - Implement eBay search web page
Name: Collin Yen
SID: 804034634
